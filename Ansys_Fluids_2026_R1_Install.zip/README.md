# Ansys Fluids Package Scripts

These scripts follow the same simple, logged, silent-install pattern as the Leximancer package:

- `Ansys_Fluids_2026_R1_Install.ps1`
- `Ansys_Fluids_2026_R1_Uninstall.ps1`

## Folder layout

```text
src
  Ansys_Fluids_2026_R1_Install.ps1
  Ansys_Fluids_2026_R1_Uninstall.ps1
  Ansys_Fluids_2026_R1_Icon.png
  build
    FLUIDS_2026R1_WINX64
      setup.exe
      ...
```

## Behaviour

- Re-runs itself through 64-bit PowerShell on 64-bit Windows if launched from a 32-bit host
- Writes script transcripts to `C:\ITD\Logs`
- Uses `setup.exe` or `AnsysInstaller.exe` from `src\build` and its subfolders
- Runs the installer in silent mode
- Runs the uninstaller in silent mode from the discovered `Uninstall.exe`
- Stops common Ansys Fluids-related processes before uninstalling and again during cleanup
- Removes the remaining release folder under `C:\Program Files\ANSYS Inc`
- Resolves the install path from the 64-bit Program Files root first (`%ProgramW6432%`), then falls back to the other Program Files variables

## Assumptions

- The package name/version shown in logs is `Ansys Fluids_2026_R1`
- The target release folder is `C:\Program Files\ANSYS Inc\v261`
- If your media targets a different release, update the default `Install Dir` in the install script.

## Detection method:

- Rule type: File
- Path: C:\Program Files\ANSYS Inc\v261\v261
- File or folder: ProductConfig.exe
- Detection method: File version
- Operator: Equals
- Version: 26.1.0.0
