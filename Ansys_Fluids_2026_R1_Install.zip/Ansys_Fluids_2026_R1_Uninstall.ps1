param(
    [string]$InstallRoot = $null
)

if ([Environment]::Is64BitOperatingSystem -and -not [Environment]::Is64BitProcess) {
    $PowerShell64 = "$env:WINDIR\SysNative\WindowsPowerShell\v1.0\powershell.exe"
    & $PowerShell64 -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath @args
    exit $LASTEXITCODE
}

$ScriptPath = $PSScriptRoot
if (-not $ScriptPath) { $ScriptPath = $PWD.Path }

$ProgramFilesRoot = ${env:ProgramW6432}
if (-not $ProgramFilesRoot) { $ProgramFilesRoot = ${env:ProgramFiles} }
if (-not $ProgramFilesRoot) { $ProgramFilesRoot = ${env:ProgramFiles(x86)} }

if (-not $InstallRoot) {
    $InstallRoot = Join-Path -Path $ProgramFilesRoot -ChildPath "ANSYS Inc"
}

if (!(Test-Path -Path "C:\ITD\Logs")) {
    New-Item -Path "C:\ITD\Logs" -ItemType Directory -Force | Out-Null
}

$AppName = "Ansys Fluids"
$AppVersion = "2026 R1"
$AppFullName = $AppName + "_2026_R1"
$UninstallLog = "C:\ITD\Logs\" + $AppFullName + "_script_uninstall.log"

$InstallDir = Join-Path -Path $InstallRoot -ChildPath "v261"
$UninstallExe = Join-Path -Path $InstallDir -ChildPath "Uninstall.exe"

Start-Transcript -Path $UninstallLog -Append -NoClobber
Write-Host "$(Get-Date) * Starting uninstall of $AppFullName *"
Write-Host "$(Get-Date) * Application version: $AppVersion *"
Write-Host "$(Get-Date) * Script path: $ScriptPath *"
Write-Host "$(Get-Date) * Host process: $([Environment]::Is64BitProcess) / OS: $([Environment]::Is64BitOperatingSystem) *"
Write-Host "$(Get-Date) * Program Files root: $ProgramFilesRoot *"
Write-Host "$(Get-Date) * Install root: $InstallRoot *"
Write-Host "$(Get-Date) * Install directory: $InstallDir *"
Write-Host "$(Get-Date) * Looking for uninstall launcher: $UninstallExe *"

if (!(Test-Path -Path $UninstallExe -PathType Leaf)) {
    Write-Host "$(Get-Date) Uninstall.exe not found: $UninstallExe"
    Stop-Transcript
    $Host.SetShouldExit(2)
    EXIT 2
}

$ProcessNames = @("fluent", "cfdpost", "cfx5pre", "cfx5solver", "icemcfd", "runwb2", "ansysedt")
Write-Host "$(Get-Date) * Checking for running Ansys processes *"
foreach ($ProcessName in $ProcessNames) {
    Get-Process -Name $ProcessName -ErrorAction SilentlyContinue | ForEach-Object {
        Write-Host "$(Get-Date) Stopping process $($_.ProcessName) (PID $($_.Id))."
        Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
    }
}
Write-Host "$(Get-Date) * Process scan complete *"

$Arguments = @(
    "-silent"
)

Write-Host "$(Get-Date) * Launching uninstaller *"
Write-Host "$(Get-Date) * Arguments: $($Arguments -join ' ') *"

$Uninstall = Start-Process -FilePath $UninstallExe -Wait -ArgumentList $Arguments -PassThru
$SuccessExitCodes = @(0, 1605, 3010)
$ExitCode = $Uninstall.ExitCode

if ($SuccessExitCodes -notcontains $Uninstall.ExitCode) {
    Write-Host "$(Get-Date) $AppFullName uninstall failed. Exit Code: $($Uninstall.ExitCode)"
} else {
    if ($Uninstall.ExitCode -eq 1605) {
        Write-Host "$(Get-Date) $AppFullName is not installed. Treating exit code 1605 as success."
        $ExitCode = 0
    } elseif ($Uninstall.ExitCode -eq 3010) {
        Write-Host "$(Get-Date) $AppFullName uninstall requested reboot. Treating exit code 3010 as script success."
        $ExitCode = 0
    } else {
        Write-Host "$(Get-Date) $AppFullName uninstall succeeded. Exit Code: $($Uninstall.ExitCode)"
    }

    Write-Host "$(Get-Date) * Running post-uninstall process cleanup *"
    foreach ($ProcessName in $ProcessNames) {
        Get-Process -Name $ProcessName -ErrorAction SilentlyContinue | ForEach-Object {
            Write-Host "$(Get-Date) Stopping process $($_.ProcessName) (PID $($_.Id)) after uninstall."
            Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
        }
    }

    if (Test-Path -Path $InstallDir) {
        Write-Host "$(Get-Date) * Removing install directory: $InstallDir *"
        Remove-Item -Path $InstallDir -Recurse -Force -ErrorAction SilentlyContinue
        if (!(Test-Path -Path $InstallDir)) {
            Write-Host "$(Get-Date) Removed remaining install directory: $InstallDir"
        }
    } else {
        Write-Host "$(Get-Date) Install directory already absent: $InstallDir"
    }

    if (Test-Path -Path $InstallRoot) {
        Write-Host "$(Get-Date) * Checking whether install root is empty: $InstallRoot *"
        $RemainingItems = @(Get-ChildItem -Path $InstallRoot -Force -ErrorAction SilentlyContinue)
        if ($RemainingItems.Count -eq 0) {
            Write-Host "$(Get-Date) * Install root is empty, removing it *"
            Remove-Item -Path $InstallRoot -Recurse -Force -ErrorAction SilentlyContinue
            if (!(Test-Path -Path $InstallRoot)) {
                Write-Host "$(Get-Date) Removed empty install root: $InstallRoot"
            }
        } else {
            Write-Host "$(Get-Date) Install root not removed because items remain: $($RemainingItems.Count)"
        }
    } else {
        Write-Host "$(Get-Date) Install root already absent: $InstallRoot"
    }
}

Write-Host "$(Get-Date) * Ending uninstall transcript *"
Stop-Transcript
$Host.SetShouldExit($ExitCode)
EXIT $ExitCode
